# super herramientas redles

Werkzeug==0.16.1
sqlalchemy==1.3.5
pandas==1.3.5