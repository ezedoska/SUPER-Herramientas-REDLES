import pandas as pd
from procs.logger import log, logB
from procs.db import engine
from PyQt5 import QtWidgets, QtGui
import datetime
import os


def cruzar_anexo(ui):
    pass